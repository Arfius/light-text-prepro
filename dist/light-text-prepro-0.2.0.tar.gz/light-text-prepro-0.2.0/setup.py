# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['light_text_prepro']

package_data = \
{'': ['*'], 'light_text_prepro': ['rules/*']}

install_requires = \
['PyYAML>=5.4.1,<6.0.0', 'flake8>=3.9.1,<4.0.0']

setup_kwargs = {
    'name': 'light-text-prepro',
    'version': '0.2.0',
    'description': '',
    'long_description': None,
    'author': 'Alfonso Farruggia',
    'author_email': 'alfarruggia@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
